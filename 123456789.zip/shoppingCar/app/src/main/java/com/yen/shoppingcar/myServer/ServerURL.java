package com.yen.shoppingcar.myServer;

public class ServerURL {

    public static final String Shop_URL = "http://10.0.2.2:8081/CA107G1/shopItem/shopItem.do";
   //public static final String Member_URL = "http://10.0.2.2:8081/CA107G1/member/member.do";
    public static final String Member_URL = "http://10.0.2.2:8081/CA107G1/member/member.do";
}
