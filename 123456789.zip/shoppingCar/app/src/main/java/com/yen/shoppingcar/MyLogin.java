package com.yen.shoppingcar;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.yen.shoppingcar.VO.MemberVO;
import com.yen.shoppingcar.myServer.CommonTask;
import com.yen.shoppingcar.myServer.ServerURL;


public class MyLogin extends AppCompatActivity {
    private Button btnLogin, btnRegist;
    private EditText tvmemID, tvmemPass;
    private CommonTask isMemberTask;
    MemberVO memberVO;
    JsonObject jsonObject;
    String user, password;
    TextInputLayout tilMemId, tilMemPsw;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btnLogin = findViewById(R.id.btnLogin);
        btnRegist = findViewById(R.id.btnRegist);
        tvmemID = findViewById(R.id.tvmemID);
        tvmemPass = findViewById(R.id.tvmemPass);
        tilMemId = findViewById(R.id.tilMemId);
        tilMemPsw = findViewById(R.id.tilMemPsw);
        setResult(RESULT_CANCELED);
    }

    @Override
    protected void onStart() {
        super.onStart();
        SharedPreferences sharedPreferences = getSharedPreferences(Util.PREF_FILE, MODE_PRIVATE);
        boolean login = sharedPreferences.getBoolean("login", false);
        if (login) {
            String userId = sharedPreferences.getString("userId", "");
            String password = sharedPreferences.getString("password", "");
            if (isMember(userId, password)) {
                setResult(RESULT_OK);
                finish();
            }
        }
    }

//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        if(requestCode )
//    }

    private boolean isMember(final String mem_account, final String mem_password) {
        boolean isMember = false;
        if (Util.networkConnected(this)) {
            String url = ServerURL.Member_URL;
            JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty("action", "isMember");
            jsonObject.addProperty("mem_account", mem_account);
            jsonObject.addProperty("mem_password", mem_password);
            String jsonOut = jsonObject.toString();
            isMemberTask = new CommonTask(url, jsonOut);
            try {
                String result = isMemberTask.execute().get();
                isMember = Boolean.valueOf(result);
            } catch (Exception e) {
                Log.e("ERRRRRRRRRROR", e.toString());
                isMember = false;
            }
        } else {
            Toast.makeText(this, "no connection", Toast.LENGTH_SHORT).show();
        }
        return isMember;
    }

    public void onLoginClick(View view) {
        String user = tvmemID.getText().toString().trim();
        String password = tvmemPass.getText().toString().trim();
        if (user.length() <= 0 || password.length() <= 0) {
            Toast.makeText(this, "帳號或密碼錯誤", Toast.LENGTH_SHORT).show();
            return;
        }
        if (isMember(user, password)) {
            SharedPreferences sharedPreferences = getSharedPreferences(Util.PREF_FILE, MODE_PRIVATE);
            sharedPreferences.edit().putBoolean("login", true)
                    .putString("user", user)
                    .putString("password", password).apply();
            setResult(RESULT_OK);
            finish();
        } else {
            Toast.makeText(this, "帳號或密碼錯誤", Toast.LENGTH_SHORT).show();
        }
    }
}
