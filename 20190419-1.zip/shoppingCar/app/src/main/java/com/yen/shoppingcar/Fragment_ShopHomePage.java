package com.yen.shoppingcar;


import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.youth.banner.Banner;
import com.youth.banner.BannerConfig;
import com.youth.banner.loader.ImageLoader;

import java.util.ArrayList;
import java.util.List;


public class Fragment_ShopHomePage extends Fragment {
    Banner banner;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_shop_home_page, container, false);
        banner = view.findViewById(R.id.banner);
        banner.setImageLoader(new GlideImageLoader());
        List<String> list = new ArrayList<>();
        list.add("https://imgur.dcard.tw/5Ju2c2t.jpg");
        list.add("https://cdn2.ettoday.net/images/1943/d1943865.jpg");
        list.add("https://video.nextmag.com.tw/photo/2016/07/14/1_1468495982439_606484_ver1.0.jpg");
        banner.setBannerStyle(BannerConfig.CIRCLE_INDICATOR);
        banner.setImages(list);
        banner.isAutoPlay(true);
        banner.setDelayTime(2000);
        banner.start();
        return view;
    }

    public class GlideImageLoader extends ImageLoader {

        @Override
        public void displayImage(Context context, Object path, ImageView imageView) {
            Glide.with(context).load((String) path).into(imageView);

        }
    }

}
