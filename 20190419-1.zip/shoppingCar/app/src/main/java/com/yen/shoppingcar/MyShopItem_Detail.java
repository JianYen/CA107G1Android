package com.yen.shoppingcar;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

import com.yen.shoppingcar.VO.ShopItemVO;

public class MyShopItem_Detail extends AppCompatActivity {
    ImageView shopItemImage;
    TextView shopItemTitle, shopItemContent;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopitem_detail);
        shopItemImage = findViewById(R.id.shopItemImage);
        shopItemTitle = findViewById(R.id.shopItemTitle);
        shopItemContent = findViewById(R.id.shopItemContent);

        Intent intent = getIntent();
        ShopItemVO shopItemVO = (ShopItemVO) intent.getExtras().getSerializable("ShopItemVO");
        shopItemTitle.setText(shopItemVO.getS_item_text());
        shopItemContent.setText(shopItemVO.getS_item_describe());


    }



}
