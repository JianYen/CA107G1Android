package com.yen.shoppingcar.VO;

public class Member_SettingListVO {
    private String text;

    public Member_SettingListVO() {
    }

    public Member_SettingListVO(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }


}
