package com.yen.shoppingcar;


import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.yen.shoppingcar.VO.Member_SettingListVO;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class Fragment_member extends Fragment {



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_member, container, false);
        RecyclerView recyclerView = view.findViewById(R.id.memberRecyclerview);
        recyclerView.setHasFixedSize(true);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(view.getContext());
        recyclerView.setLayoutManager(layoutManager);

        recyclerView.setLayoutManager(new StaggeredGridLayoutManager(1, StaggeredGridLayoutManager.VERTICAL));

        List<Member_SettingListVO> teamList = new ArrayList<>();
        teamList.add(new Member_SettingListVO("會員資料"));
        teamList.add(new Member_SettingListVO("寵物資料"));
        teamList.add(new Member_SettingListVO("訂單查詢"));
        teamList.add(new Member_SettingListVO("我的收藏"));

        recyclerView.setAdapter(new memberAdapter(teamList));

        return view;
    }

    private class memberAdapter extends RecyclerView.Adapter<Fragment_member.memberAdapter.ViewHolder> {
        private List<Member_SettingListVO> teamList;

        private memberAdapter(List<Member_SettingListVO> teamList) {
            this.teamList = teamList;
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            private TextView tvMember;

            private ViewHolder(View view) {
                super(view);
                tvMember = view.findViewById(R.id.tvMember);
            }
        }

        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_member_settinglist, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {
            final Member_SettingListVO member_settingList = teamList.get(position);
            viewHolder.tvMember.setText(member_settingList.getText());
        }

        @Override
        public int getItemCount() {
            return teamList.size();
        }

    }


}
