package com.yen.shoppingcar;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import de.hdodenhof.circleimageview.CircleImageView;

public class MyMainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, ViewPager.OnPageChangeListener {
    private BottomNavigationView bottomNavigationView;
    private ViewPager viewPager;
    private SharedPreferences loginSharePreference;
    CircleImageView circleImageView;
    Button navLogin;
    TextView navName;
    DrawerLayout drawerLayout;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        PagerAdapter pagerAdapter = new PagerAdapter(getSupportFragmentManager());
        viewPager = findViewById(R.id.viewPager);
        viewPager.setAdapter(pagerAdapter);
        viewPager.addOnPageChangeListener(this);
navLogin.setText("登入");

        bottomNavigationView = findViewById(R.id.bottom_bar);
        bottomNavigationView.setOnNavigationItemSelectedListener(onNavigationItemSelectedListener);
//        NavigationHeader();
    }


    private BottomNavigationView.OnNavigationItemSelectedListener onNavigationItemSelectedListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                    viewPager.setCurrentItem(menuItem.getOrder());
                    return true;
                }

            };

    @Override
    public void onPageScrolled(int i, float v, int i1) {

    }

    @Override
    public void onPageSelected(int position) {
        bottomNavigationView.getMenu().getItem(position).setChecked(true);
    }

    @Override
    public void onPageScrollStateChanged(int i) {

    }

    public void onNavLoginClick(View view) {

        if("登入".equals(navLogin.getText().toString())){
            Intent intent = new Intent(MyMainActivity.this, MyLogin.class);
                startActivity(intent);
                drawerLayout.closeDrawer(GravityCompat.START);
        } else if("登出".equals(navLogin.getText().toString())){
            loginSharePreference.edit().clear().apply();
                drawerLayout.closeDrawer(GravityCompat.START);
            NavigationHeader();
        }
//        switch (navLogin.getText().toString()) {
//            case "登入":
//                Intent intent = new Intent(MyMainActivity.this, MyLogin.class);
//                startActivity(intent);
//                drawerLayout.closeDrawer(GravityCompat.START);
//            case "登出":
//                loginSharePreference.edit().clear().apply();
//                drawerLayout.closeDrawer(GravityCompat.START);
//                NavigationHeader();
//        }
    }

    private class PagerAdapter extends FragmentPagerAdapter {

        public PagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            switch (position) {
                case 0:
                    return new Fragment_HomePage();

                case 1:
                    return new Fragment_member();

                case 2:
                    return new Fragment_ShopHomePage();
            }
            return null;
        }

        @Override
        public int getCount() {
            return 3;
        }
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    @Override
    public boolean onNavigationItemSelected(MenuItem menuItem) {
        Intent intent = new Intent();
        // Handle navigation view item clicks here.
        switch (menuItem.getItemId()) {
            case R.id.nav_mem:
                intent.setClass(MyMainActivity.this, MyShopItem_Detail.class);
                break;

            case R.id.nav_news:
                intent.setClass(MyMainActivity.this, MyShopItem_Detail.class);
                break;

            case R.id.nav_favorite:
                return true;


            case R.id.nav_order:
                return true;

            case R.id.nav_hotel:
                intent.setClass(MyMainActivity.this, MyShopItem_Browse.class);
                break;
            case R.id.nav_shop:
                intent.setClass(MyMainActivity.this, MyShopItem_Browse.class);
                break;
        }
        startActivity(intent);

        DrawerLayout drawer = findViewById(R.id.drawer_layout123);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void NavigationHeader() {
        drawerLayout = findViewById(R.id.drawer_layout);
        circleImageView = findViewById(R.id.circleImage);
        navName = findViewById(R.id.navName);
        navLogin = findViewById(R.id.navLogin);
        loginSharePreference = getSharedPreferences("login", Context.MODE_PRIVATE);

        String userId = loginSharePreference.getString("userId", null);
        if (userId != null) {
            navName.setText(userId);
            navLogin.setText("登出");
        } else {
            navName.setText(R.string.notLogin);
            navLogin.setText(R.string.Login);

        }


    }


//    public void onLogin() {
//        switch ((String) navLogin.getText()) {
//            case "登入":
//                Intent intent = new Intent(MyMainActivity.this, MyLogin.class);
//                startActivity(intent);
//                drawerLayout.closeDrawer(GravityCompat.START);
//            case "登出":
//                loginSharePreference.edit().clear().apply();
//                drawerLayout.closeDrawer(GravityCompat.START);
//                NavigationHeader();
//        }
//    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

}
